//
//  ForgotPasswordViewController.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//

import UIKit
import SnapKit

class ForgotPasswordViewController: UIViewController {
    
    private let viewModel: ForgotPasswordViewModel
    
    private lazy var emailTextField: UITextField = makeTextField(placeholder: "Email")
    private lazy var resetButton: UIButton = makeButton(title: "Reset Password", action: #selector(resetButtonTapped))
    
    init(viewModel: ForgotPasswordViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        view.backgroundColor = .white
        view.addSubview(emailTextField)
        view.addSubview(resetButton)
        
        emailTextField.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            $0.leading.trailing.equalToSuperview().inset(20)
        }
        
        resetButton.snp.makeConstraints {
            $0.top.equalTo(emailTextField.snp.bottom).offset(20)
            $0.leading.trailing.equalToSuperview().inset(20)
        }
    }
    
    @objc private func resetButtonTapped() {
        guard let email = emailTextField.text else { return }
        viewModel.email = email
        viewModel.resetPassword { success, error in
            if success {
                print("Password reset request sent successfully")
                // Handle success, e.g., show a success message to the user
            } else {
                if let error = error {
                    print("Error during password reset: \(error.localizedDescription)")
                    // Handle error, e.g., show an error message to the user
                } else {
                    print("Unknown error during password reset")
                    // Handle unknown error, e.g., show a generic error message to the user
                }
            }
        }
    }
    
    private func makeTextField(placeholder: String) -> UITextField {
        let textField = UITextField()
        textField.placeholder = placeholder
        textField.borderStyle = .roundedRect
        return textField
    }
    
    private func makeButton(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }
}
