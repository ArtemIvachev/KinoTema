//
//  LoginViewController.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//


import UIKit

protocol LoginView: AnyObject {
    func showLoginSuccess()
    func showLoginError(message: String)
    func showRegistrationScreen()
    func showForgotPasswordScreen()
}

class LoginViewController: UIViewController, LoginView {
    
    var viewModel: LoginViewModel
    var router: AuthenticationRouter?
    
    init(viewModel: LoginViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    // Обработчик нажатия кнопки "Войти"
    @objc func loginButtonTapped() {
        viewModel.loginUser { success, error in
            if success {
                // Вход выполнен успешно
                DispatchQueue.main.async {
                    self.showLoginSuccess()
                }
            } else {
                // Вход не выполнен из-за ошибки
                DispatchQueue.main.async {
                    self.showLoginError(message: error?.localizedDescription ?? "Unknown error")
                }
            }
        }
    }
    
    // Обработчик нажатия кнопки "Зарегистрироваться"
    @objc func registerButtonTapped() {
        showRegistrationScreen()
    }
    
    // Обработчик нажатия кнопки "Забыл пароль"
    @objc func forgotPasswordButtonTapped() {
        showForgotPasswordScreen()
    }
    
    private func setupView() {
        // Заголовок "Войти в профиль"
        let titleLabel = UILabel()
        titleLabel.text = "Войти в профиль"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 24)
        titleLabel.textAlignment = .center
        titleLabel.textColor = .white
        view.addSubview(titleLabel)
        
        // Кнопка "Зарегистрироваться"
        let registerButton = UIButton(type: .system)
        registerButton.setTitle("Зарегистрироваться", for: .normal)
        registerButton.addTarget(self, action: #selector(registerButtonTapped), for: .touchUpInside)
        view.addSubview(registerButton)
        
        // Создание текстовых полей для ввода email и пароля
        let emailTextField = UITextField()
        emailTextField.placeholder = "Email"
        emailTextField.borderStyle = .roundedRect
        emailTextField.autocapitalizationType = .none
        emailTextField.autocorrectionType = .no
        view.addSubview(emailTextField)
        
        let passwordTextField = UITextField()
        passwordTextField.placeholder = "Password"
        passwordTextField.borderStyle = .roundedRect
        passwordTextField.isSecureTextEntry = true
        view.addSubview(passwordTextField)
        
        // Создание кнопки "Войти"
        let loginButton = UIButton(type: .system)
        loginButton.setTitle("Войти", for: .normal)
        loginButton.addTarget(self, action: #selector(loginButtonTapped), for: .touchUpInside)
        view.addSubview(loginButton)
        
        // Кнопка "Забыл пароль"
        let forgotPasswordButton = UIButton(type: .system)
        forgotPasswordButton.setTitle("Забыл пароль", for: .normal)
        forgotPasswordButton.addTarget(self, action: #selector(forgotPasswordButtonTapped), for: .touchUpInside)
        view.addSubview(forgotPasswordButton)
        
        // Установка ограничений для UI-элементов
        titleLabel.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(50)
            $0.centerX.equalToSuperview()
        }
        
        registerButton.snp.makeConstraints {
            $0.top.equalTo(titleLabel.snp.bottom).offset(20)
            $0.centerX.equalToSuperview()
        }
        
        emailTextField.snp.makeConstraints {
            $0.top.equalTo(registerButton.snp.bottom).offset(20)
            $0.leading.equalToSuperview().offset(20)
            $0.trailing.equalToSuperview().offset(-20)
        }
        
        passwordTextField.snp.makeConstraints {
            $0.top.equalTo(emailTextField.snp.bottom).offset(20)
            $0.leading.trailing.equalTo(emailTextField)
        }
        
        loginButton.snp.makeConstraints {
            $0.top.equalTo(passwordTextField.snp.bottom).offset(20)
            $0.leading.trailing.equalTo(emailTextField)
        }
        
        forgotPasswordButton.snp.makeConstraints {
            $0.top.equalTo(loginButton.snp.bottom).offset(20)
            $0.centerX.equalToSuperview()
        }
    }
    
    func showRegistrationScreen() {
        router?.showRegistrationScreen()
    }
    
    func showForgotPasswordScreen() {
        router?.showForgotPasswordScreen()
    }
    
    func showLoginSuccess() {
        // Переход к следующему экрану (к профилю пользователя)
    }
    
    func showLoginError(message: String) {
        // Отображение сообщения об ошибке
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
