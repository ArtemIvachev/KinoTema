//
//  RegistrationViewController.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//

import UIKit
import SnapKit

class RegistrationViewController: UIViewController {
    
    private let viewModel: RegistrationViewModel
    
    private lazy var nameTextField: UITextField = makeTextField(placeholder: "Name")
    private lazy var emailTextField: UITextField = makeTextField(placeholder: "Email")
    private lazy var passwordTextField: UITextField = makeTextField(placeholder: "Password", isSecure: true)
    private lazy var registerButton: UIButton = makeButton(title: "Register", action: #selector(registerButtonTapped))
    
    init(viewModel: RegistrationViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        view.backgroundColor = .white
        view.addSubview(nameTextField)
        view.addSubview(emailTextField)
        view.addSubview(passwordTextField)
        view.addSubview(registerButton)
        
        nameTextField.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            $0.leading.trailing.equalToSuperview().inset(20)
        }
        
        emailTextField.snp.makeConstraints {
            $0.top.equalTo(nameTextField.snp.bottom).offset(20)
            $0.leading.trailing.equalTo(nameTextField)
        }
        
        passwordTextField.snp.makeConstraints {
            $0.top.equalTo(emailTextField.snp.bottom).offset(20)
            $0.leading.trailing.equalTo(nameTextField)
        }
        
        registerButton.snp.makeConstraints {
            $0.top.equalTo(passwordTextField.snp.bottom).offset(20)
            $0.leading.trailing.equalTo(nameTextField)
        }
    }
    
    @objc private func registerButtonTapped() {
        guard let name = nameTextField.text,
              let email = emailTextField.text,
              let password = passwordTextField.text else {
            return
        }
        viewModel.name = name
        viewModel.email = email
        viewModel.password = password
        viewModel.registerUser { success, error in
            if success {
                print("Registration successful")
                // Handle successful registration, e.g., navigate to another view controller
            } else {
                if let error = error {
                    print("Error during registration: \(error.localizedDescription)")
                } else {
                    print("Unknown error during registration")
                }
            }
        }
    }
    
    private func makeTextField(placeholder: String, isSecure: Bool = false) -> UITextField {
        let textField = UITextField()
        textField.placeholder = placeholder
        textField.isSecureTextEntry = isSecure
        textField.borderStyle = .roundedRect
        return textField
    }
    
    private func makeButton(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }
}
