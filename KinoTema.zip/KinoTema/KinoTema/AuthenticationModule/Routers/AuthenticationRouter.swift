//
//  AuthenticationRouter.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//

import UIKit

protocol AuthenticationRouter {
    func showLoginScreen()
    func showRegistrationScreen()
    func showForgotPasswordScreen()
}

final class AuthenticationRouterImpl: AuthenticationRouter {
    private let navigationController: UINavigationController
        
        init(navigationController: UINavigationController) {
            self.navigationController = navigationController
        }
    
    func showLoginScreen() {
        let loginViewModel = LoginViewModel()
        let loginViewController = LoginViewController(viewModel: loginViewModel)
        navigationController.pushViewController(loginViewController, animated: true)
    }
    
    func showRegistrationScreen() {
        let registrationViewModel = RegistrationViewModel()
        let registrationViewController = RegistrationViewController(viewModel: registrationViewModel)
        navigationController.pushViewController(registrationViewController, animated: true)
    }
    
    func showForgotPasswordScreen() {
        let forgotPasswordViewModel = ForgotPasswordViewModel()
        let forgotPasswordViewController = ForgotPasswordViewController(viewModel: forgotPasswordViewModel)
        navigationController.pushViewController(forgotPasswordViewController, animated: true)
    }
}
