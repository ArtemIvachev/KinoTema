//
//  User.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//

struct User {
    let id: Int
    let username: String
    let email: String
    let password: String
}
