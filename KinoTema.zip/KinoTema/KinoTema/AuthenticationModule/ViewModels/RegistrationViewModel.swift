//
//  RegistrationViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//

import Foundation

class RegistrationViewModel {
    // Свойства
    var name: String = ""
    var email: String = ""
    var password: String = ""
    
    // Метод для регистрации пользователя
    func registerUser(completion: @escaping (Bool, Error?) -> Void) {
        // Создаем URL для запроса на сервер
        guard let url = URL(string: "https://api.example.com/register") else {
            completion(false, NSError(domain: "Registration", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
            return
        }
        
        // Создаем словарь с данными о пользователе
        let userData: [String: Any] = ["name": name, "email": email, "password": password]
        
        // Преобразуем данные пользователя в формат JSON
        guard let jsonData = try? JSONSerialization.data(withJSONObject: userData) else {
            completion(false, NSError(domain: "Registration", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to serialize user data"]))
            return
        }
        
        // Создаем запрос на сервер
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Отправляем запрос на сервер
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Проверяем наличие ошибок
            if let error = error {
                completion(false, error)
                return
            }
            
            // Проверяем код ответа от сервера
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                completion(false, NSError(domain: "Registration", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to register user"]))
                return
            }
            
            // Если код ответа 200, значит регистрация прошла успешно
            completion(true, nil)
        }
        
        // Запускаем задачу
        task.resume()
    }
}
