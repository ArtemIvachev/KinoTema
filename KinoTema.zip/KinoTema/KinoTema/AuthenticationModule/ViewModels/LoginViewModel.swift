//
//  LoginViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//


import Foundation

class LoginViewModel {
    // Свойства
    var email: String = ""
    var password: String = ""

    // Метод для входа пользователя
    func loginUser(completion: @escaping (Bool, Error?) -> Void) {
        // Создаем URL для запроса на сервер
        guard let url = URL(string: "https://api.example.com/login") else {
            completion(false, NSError(domain: "Login", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
            return
        }

        // Создаем словарь с данными для входа пользователя
        let loginData: [String: Any] = ["email": email, "password": password]

        // Преобразуем данные в формат JSON
        guard let jsonData = try? JSONSerialization.data(withJSONObject: loginData) else {
            completion(false, NSError(domain: "Login", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to serialize login data"]))
            return
        }

        // Создаем запрос на сервер
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // Отправляем запрос на сервер
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Проверяем наличие ошибок
            if let error = error {
                completion(false, error)
                return
            }

            // Проверяем код ответа от сервера
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                completion(false, NSError(domain: "Login", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to log in"]))
                return
            }

            // Если код ответа 200, значит вход выполнен успешно
            completion(true, nil)
        }

        // Запускаем задачу
        task.resume()
    }
}

