//
//  AuthenticationAssembly.swift
//  KinoTema
//
//  Created by Артем Ивачев on 15.04.2024.
//

import UIKit

final public class AuthenticationAssembly {
    public static func initialViewController() -> UINavigationController {
        let navigationController = UINavigationController()
        let router = AuthenticationRouterImpl(navigationController: navigationController) // передаем navigationController здесь
        let initialViewController = LoginViewController(viewModel: LoginViewModel())
        initialViewController.router = router
        navigationController.setViewControllers([initialViewController], animated: false)
        return navigationController
    }
}
