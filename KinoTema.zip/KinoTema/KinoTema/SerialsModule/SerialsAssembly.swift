//
//  SerialsAssembly.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final public class SerialsAssembly {
    public static func initialViewController() -> UINavigationController {
        let router = SerialsRouterImpl()
        let filmsViewModel = SerialsViewModelImpl(router: router)
        let rootView = SerialsViewImpl(viewModel: filmsViewModel)
        let initialView = SerialsNavigationController(rootViewController: rootView)
        router.rootViewController = initialView
        return initialView
    }
}

