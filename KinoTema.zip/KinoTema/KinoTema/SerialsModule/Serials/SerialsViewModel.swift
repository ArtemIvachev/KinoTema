//
//  SerialsViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

protocol SerialsViewModel {
    var view: SerialsView? { get set }
    
    func unlikeButtonDidTapped()
    func playButtonDidTapped()
    func likeButtonDidTapped()
}

final class SerialsViewModelImpl: SerialsViewModel {
    
    weak var view: SerialsView?
    let router: SerialsRouter
    
    init(router: SerialsRouter) {
        self.router = router
    }
    
    func unlikeButtonDidTapped() {
        print("unlike")
    }
    
    func playButtonDidTapped() {
        print("play")
    }
    
    func likeButtonDidTapped() {
        print("like")
    }
}


