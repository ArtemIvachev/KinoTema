//
//  SerialRouter.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

protocol SerialsRouter {
}

final class SerialsRouterImpl: SerialsRouter {
    weak var rootViewController: UINavigationController?
}
