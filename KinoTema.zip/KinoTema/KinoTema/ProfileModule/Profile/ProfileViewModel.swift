//
//  ProfileViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

protocol ProfileViewModel {
    var view: ProfileView? { get set }
}

final class ProfileViewModelImpl: ProfileViewModel {
    weak var view: ProfileView?
    let router: ProfileRouter
    
    init(router: ProfileRouter) {
        self.router = router
    }

    func showLoginScreen() {
        // Вызываем метод роутера для открытия экрана входа
        router.showLoginScreen()
    }
}

