//
//  ProfileAssembly.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final public class ProfileAssembly {
    public static func initialViewController() -> UINavigationController {
        let router = ProfileRouterImpl()
        let profileViewModel = ProfileViewModelImpl(router: router)
        let profileView = ProfileViewImpl(viewModel: profileViewModel)
        let profileNavigationController = ProfileNavigationController(rootViewController: profileView)
        router.rootViewController = profileNavigationController
        
        // Проверяем, авторизован ли пользователь
        if !isUserLoggedIn() {
            // Если пользователь не авторизован, показываем экран входа в профиль
            router.showLoginScreen()
        }
        
        return profileNavigationController
    }
    
    private static func isUserLoggedIn() -> Bool {
        return UserDefaults.standard.bool(forKey: "isLoggedIn")
    }
}
