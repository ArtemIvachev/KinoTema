//
//  ProfileNavigation.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final class ProfileNavigationController: UINavigationController {
    
    // Роутер для управления навигацией в разделе "Профиль"
    var profileRouter: ProfileRouter?
    
    override var childForStatusBarStyle: UIViewController? {
        visibleViewController
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        visibleViewController?.preferredStatusBarStyle ?? .default
    }
    
    override init(rootViewController: UIViewController) {
        super.init(rootViewController: rootViewController)
        navigationBar.isHidden = true
        setupTabBarItem()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // Метод для обработки нажатия на раздел "Профиль"
    func handleProfileTapped() {
        // Показываем экран входа через роутер, если он задан
        profileRouter?.showLoginScreen()
    }
    
    private func setupTabBarItem() {
        tabBarItem = UITabBarItem(
            title: "Профиль",
            image: .init(systemName: "person"),
            selectedImage: .init(systemName: "person.fill"))
    }
}

