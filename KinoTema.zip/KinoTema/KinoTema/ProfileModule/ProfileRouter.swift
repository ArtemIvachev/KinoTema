//
//  ProfileRouter.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

protocol ProfileRouter {
    func showLoginScreen()
}

final class ProfileRouterImpl: ProfileRouter {
    weak var rootViewController: UINavigationController?

    func showLoginScreen() {
        // Создаем экземпляр LoginViewController и отображаем его на экране
        let loginViewModel = LoginViewModel()
        let loginViewController = LoginViewController(viewModel: loginViewModel)
        rootViewController?.pushViewController(loginViewController, animated: true)
    }
}
