//
//  SearchNavigation.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final class SearchNavigationController: UINavigationController {
    
    override var childForStatusBarStyle: UIViewController? {
        visibleViewController
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        visibleViewController?.preferredStatusBarStyle ?? .default
    }
    
    override init(rootViewController: UIViewController) {
        super.init(rootViewController: rootViewController)
        navigationBar.isHidden = true
        setupTabBarItem()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

private extension SearchNavigationController {
    func setupTabBarItem() {
        tabBarItem = UITabBarItem(
            title: "Поиск",
            image: .init(systemName: "magnifyingglass"),
            selectedImage: .init(systemName: "magnifyingglass"))
    }
}
