//
//  SearchRouter.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

protocol SearchRouter {
}

final class SearchRouterImpl: SearchRouter {
    weak var rootViewController: UINavigationController?
}
