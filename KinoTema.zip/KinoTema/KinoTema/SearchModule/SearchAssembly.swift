//
//  SearchAssembly.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final public class SearchAssembly {
    public static func initialViewController() -> UINavigationController {
        let router = SearchRouterImpl()
        let filmsViewModel = SearchViewModelImpl(router: router)
        let rootView = SearchViewImpl(viewModel: filmsViewModel)
        let initialView = SearchNavigationController(rootViewController: rootView)
        router.rootViewController = initialView
        return initialView
    }
}

