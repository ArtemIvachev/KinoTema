//
//  SearchViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

protocol SearchViewModel {
    var view: SearchView? { get set }
}

final class SearchViewModelImpl: SearchViewModel {
    weak var view: SearchView?
    let router: SearchRouter
    
    init(router: SearchRouter) {
        self.router = router
    }
}
