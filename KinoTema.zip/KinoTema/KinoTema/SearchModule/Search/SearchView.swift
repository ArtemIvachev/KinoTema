//
//  SearchView.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

protocol SearchView: AnyObject {
    
}

final class SearchViewImpl: UIViewController, SearchView {
    var viewModel: SearchViewModel
    
    init(viewModel: SearchViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
        self.viewModel.view = self
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
