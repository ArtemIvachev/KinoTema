//
//  ViewController.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final class MainTabBarView: UITabBarController {
    
    private let viewModel: MainTabBarViewModel
    
    init(viewModel: MainTabBarViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewControllers = viewModel.viewControllers
        setupTabBar()
    }
}

private extension MainTabBarView {
    func setupTabBar() {
        tabBar.backgroundColor = .white
    }
}

