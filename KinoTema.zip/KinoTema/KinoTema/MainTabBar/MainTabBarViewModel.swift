//
//  MainTabBarViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

protocol MainTabBarViewModel {
    var viewControllers: [UIViewController] { get }
}

final class MainTabBarViewModelImpl: MainTabBarViewModel {
    var viewControllers: [UIViewController] {
        let filmsView = FilmsAssembly.initialViewController()
        let serialsView = SerialsAssembly.initialViewController()
        let searchView = SearchAssembly.initialViewController()
        let profileView = ProfileAssembly.initialViewController()
        return [filmsView, serialsView, searchView, profileView]
    }
}
