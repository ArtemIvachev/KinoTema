//
//  ButtonsAssembly.swift
//  KinoTema
//
//  Created by Артем Ивачев on 14.04.2024.
//

import UIKit
