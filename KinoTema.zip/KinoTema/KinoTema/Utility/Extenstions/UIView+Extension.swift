//
//  UIView+Extension.swift
//  KinoTema
//
//  Created by Артем Ивачев on 14.04.2024.
//

import UIKit

extension UIView {
    func addSubviews(_ views: UIView...) {
        views.forEach { addSubview($0) }
    }
}
