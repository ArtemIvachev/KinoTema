//
//  UIImage+Extension.swift
//  KinoTema
//
//  Created by Артем Ивачев on 14.04.2024.
//

import UIKit

extension UIImage {
    func resized(toAspectFit size: CGSize) -> UIImage? {
        let ratio = min(size.width / self.size.width, size.height / self.size.height)
        let newSize = CGSize(width: self.size.width * ratio, height: self.size.height * ratio)
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: newSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}
