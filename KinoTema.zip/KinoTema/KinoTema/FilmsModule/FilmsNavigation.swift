//
//  FilmsNavigation.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final class FilmsNavigationController: UINavigationController {
    
    override var childForStatusBarStyle: UIViewController? {
        visibleViewController
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        visibleViewController?.preferredStatusBarStyle ?? .default
    }
    
    override init(rootViewController: UIViewController) {
        super.init(rootViewController: rootViewController)
        navigationBar.isHidden = true
        setupTabBarItem()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

private extension FilmsNavigationController {
    func setupTabBarItem() {
        tabBarItem = UITabBarItem(
            title: "Фильмы",
            image: .init(systemName: "film"),
            selectedImage: .init(systemName: "film.fill"))
    }
}
