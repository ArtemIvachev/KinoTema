//
//  FilmsRouter.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

protocol FilmsRouter {
}

final class FilmsRouterImpl: FilmsRouter {
    weak var rootViewController: UINavigationController?
}
