//
//  FilmsAssembly.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit

final public class FilmsAssembly {
    public static func initialViewController() -> UINavigationController {
        let router = FilmsRouterImpl()
        let filmsViewModel = FilmsViewModelImpl(router: router)
        let rootView = FilmsViewImpl(viewModel: filmsViewModel)
        let initialView = FilmsNavigationController(rootViewController: rootView)
        router.rootViewController = initialView
        return initialView
    }
}
