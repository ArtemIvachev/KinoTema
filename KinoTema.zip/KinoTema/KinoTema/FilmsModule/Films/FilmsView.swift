//
//  FilmsView.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

import UIKit
import SnapKit

protocol FilmsView: AnyObject {
    
}

final class FilmsViewImpl: UIViewController, FilmsView {
    
    private enum Constants {
        static let verticalOffset: CGFloat = 14
        static let horizontalInset: CGFloat = 20
        static let buttonSize: CGFloat = 70
        static let percentHeightPoster: CGFloat = 0.6
        static let percentWidthButtonStackView: CGFloat = 0.8
        static let cornerRadiusGenre: CGFloat = 10
    }
    
    private var viewModel: FilmsViewModel
    
    private lazy var posterImageView: UIImageView = makeImageView(named: "firstPlayer")
    private lazy var nameLabel: UILabel = makeLabel(text: "Ready Player One (2018)", fontSize: 18)
    private lazy var infoLabel: UILabel = makeLabel(text: "USA, India, 2 h 20 min. 12+", fontSize: 14)
    private lazy var genresStackView: UIStackView = makeStackView(arrangedSubviews: makeGenres(), axis: .horizontal, distribution: .equalSpacing, alignment: .leading)
    private lazy var descriptionLabel: UILabel = makeLabel(text: "Teenager hunts for Easter eggs in a virtual game that has taken over the world. Fantasy action by Steven Spielberg.", fontSize: 16)
    private lazy var buttonsStackView: UIStackView = makeStackView(arrangedSubviews: makeButtons(), axis: .horizontal, distribution: .equalSpacing)
    
    init(viewModel: FilmsViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setupConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

private extension FilmsViewImpl {
    func setupView() {
        viewModel.view = self
        view.addSubviews(posterImageView, genresStackView, descriptionLabel, buttonsStackView)
        posterImageView.addSubviews(nameLabel, infoLabel)
    }
    
    func setupConstraints() {
        let tabBarHeight = tabBarController?.tabBar.frame.height ?? 0
        
        posterImageView.snp.makeConstraints {
            $0.top.width.centerX.equalToSuperview()
            $0.width.equalToSuperview()
            $0.height.equalToSuperview().multipliedBy(Constants.percentHeightPoster)
        }
        
        nameLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.bottom.equalTo(infoLabel.snp.top)
        }
        
        infoLabel.snp.makeConstraints {
            $0.centerX.bottom.equalToSuperview()
        }
        
        genresStackView.snp.makeConstraints {
            $0.top.equalTo(posterImageView.snp.bottom).offset(Constants.verticalOffset)
            $0.leading.equalToSuperview().inset(Constants.horizontalInset)
        }
        
        descriptionLabel.snp.makeConstraints {
            $0.top.equalTo(genresStackView.snp.bottom).offset(Constants.verticalOffset)
            $0.horizontalEdges.equalToSuperview().inset(Constants.horizontalInset)
        }
        
        buttonsStackView.snp.makeConstraints {
            $0.width.equalToSuperview().multipliedBy(Constants.percentWidthButtonStackView)
            $0.height.equalTo(Constants.buttonSize)
            $0.centerX.equalToSuperview()
            $0.bottom.equalToSuperview().offset(-tabBarHeight - Constants.verticalOffset )
        }
    }
    
    func makeStackView(arrangedSubviews: [UIView], 
                       axis: NSLayoutConstraint.Axis,
                       distribution: UIStackView.Distribution,
                       alignment: UIStackView.Alignment = .fill) -> UIStackView {
        let stackView = UIStackView(arrangedSubviews: arrangedSubviews)
        stackView.axis = axis
        stackView.distribution = distribution
        stackView.alignment = alignment
        return stackView
    }
    
    func makeImageView(named imageName: String) -> UIImageView {
        let imageView = UIImageView(image: UIImage(named: imageName))
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        return imageView
    }
    
    func makeLabel(text: String, fontSize: CGFloat, backgroundColor: UIColor = .clear) -> UILabel {
        let label = UILabel()
        label.text = text
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 0
        label.textColor = .white
        label.textAlignment = .justified
        label.font = UIFont.systemFont(ofSize: fontSize)
        label.backgroundColor = backgroundColor
        return label
    }
    
    func makeButtons() -> [UIButton] {
        let unlikeButton = makeCircleButton(named: "multiply", tintColor: .red, borderColor: .red, action: viewModel.unlikeButtonDidTapped)
        let playButton = makeCircleButton(named: "play.fill", tintColor: .black, backgroundColor: .white, borderColor: .white, action: viewModel.playButtonDidTapped)
        let likeButton = makeCircleButton(named: "heart.fill", tintColor: .green, borderColor: .green, action: viewModel.likeButtonDidTapped)
        return [unlikeButton, playButton, likeButton]
    }
    
    func makeGenres() -> [UILabel] {
        let firstGenre = makeLabel(text: "  sci-fi  ", fontSize: 20, backgroundColor: .systemBlue)
        let secondGenre = makeLabel(text: "  action  ", fontSize: 20, backgroundColor: .systemOrange)
        let thirdGenre = makeLabel(text: "  adventure  ", fontSize: 20, backgroundColor: .systemGreen)
        
        [firstGenre, secondGenre, thirdGenre].forEach {
            $0.layer.cornerRadius = Constants.cornerRadiusGenre
            $0.clipsToBounds = true
        }
        
        return [firstGenre, secondGenre, thirdGenre]
    }
    
    func makeCircleButton(named imageName: String, 
                          tintColor: UIColor,
                          backgroundColor: UIColor = .black,
                          borderColor: UIColor,
                          action: @escaping () -> Void) -> UIButton {
        let button = UIButton(type: .custom)
        button.backgroundColor = backgroundColor
        button.layer.cornerRadius = Constants.buttonSize / 2
        button.layer.borderWidth = 1.0
        button.layer.borderColor = borderColor.cgColor
        button.clipsToBounds = true
        
        let image = UIImage(systemName: imageName)?.withTintColor(tintColor, renderingMode: .alwaysOriginal)
        button.setImage(image, for: .normal)
        
        button.addAction(UIAction(handler: { _ in
            action()
        }), for: .touchUpInside)
        
        button.snp.makeConstraints {
            $0.size.equalTo(Constants.buttonSize)
        }
        
        return button
    }
}
