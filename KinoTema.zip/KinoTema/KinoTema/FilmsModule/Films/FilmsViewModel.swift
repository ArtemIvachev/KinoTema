//
//  FilmsViewModel.swift
//  KinoTema
//
//  Created by Артем Ивачев on 07.04.2024.
//

protocol FilmsViewModel {
    var view: FilmsView? { get set }
    
    func unlikeButtonDidTapped()
    func playButtonDidTapped()
    func likeButtonDidTapped()
}

final class FilmsViewModelImpl: FilmsViewModel {
    
    weak var view: FilmsView?
    let router: FilmsRouter
    
    init(router: FilmsRouter) {
        self.router = router
    }
    
    func unlikeButtonDidTapped() {
        print("unlike")
    }
    
    func playButtonDidTapped() {
        print("play")
    }
    
    func likeButtonDidTapped() {
        print("like")
    }
}
