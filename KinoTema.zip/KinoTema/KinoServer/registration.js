const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'KINOTEMA',
    password: 'Barsagovno123',
    port: 5433,
});

// Функция для регистрации нового пользователя
async function registerUser(username, email, password) {
    try {
        const client = await pool.connect();
        const query = 'INSERT INTO users (username, email, password) VALUES ($1, $2, $3)';
        const values = [username, email, password];
        const result = await client.query(query, values);
        client.release();
        return result.rows[0];
    } catch (error) {
        console.error('Error during user registration:', error);
        throw error;
    }
}

// Ипользования функции для регистрации нового пользователя
registerUser('example_user', 'example@example.com', 'password123')
    .then(() => {
        console.log('User registered successfully');
    })
    .catch((error) => {
        console.error('Failed to register user:', error);
    });