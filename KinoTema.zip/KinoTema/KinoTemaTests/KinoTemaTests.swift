//
//  KinoTemaTests.swift
//  KinoTemaTests
//
//  Created by Артем Ивачев on 07.04.2024.
//

import XCTest
@testable import KinoTema

class KinoTemaNavigationTests: XCTestCase {
    
    var mainTabBarController: MainTabBarView!
    
    override func setUpWithError() throws {
        // Создаем экземпляр MainTabBarViewModelImpl
        let viewModel = MainTabBarViewModelImpl()
        // Создаем экземпляр MainTabBarView и передаем viewModel
        mainTabBarController = MainTabBarView(viewModel: viewModel)
        // Загружаем представления
        mainTabBarController.loadViewIfNeeded()
    }
    
    override func tearDownWithError() throws {
        mainTabBarController = nil
    }
    
    func testNavigationToFilms() throws {
        // Проверяем, что вкладка "Фильмы" доступна
        XCTAssertEqual(mainTabBarController.viewControllers?.count, 4)
        // Выбираем первый контроллер из tabBar
        let filmsNavigationController = mainTabBarController.viewControllers?[0] as? UINavigationController
        XCTAssertNotNil(filmsNavigationController)
        
        // Получаем верхний контроллер в стеке навигации (это представление фильмов)
        let filmsViewController = filmsNavigationController?.topViewController as? FilmsViewImpl
        XCTAssertNotNil(filmsViewController)
        
        // Проверяем, что представление фильмов не равно nil
        XCTAssertNotNil(filmsViewController)
    }
    
    func testNavigationToSerials() throws {
        // Проверяем, что вкладка "Фильмы" доступна
        XCTAssertEqual(mainTabBarController.viewControllers?.count, 4)
        
        // Выбираем первый контроллер из tabBar
        let serialsNavigationController = mainTabBarController.viewControllers?[1] as? UINavigationController
        XCTAssertNotNil(serialsNavigationController)
        
        // Получаем верхний контроллер в стеке навигации (это представление сериалов)
        // Здесь объявляем переменную serialsViewController
        let serialsViewController = serialsNavigationController?.topViewController as? SerialsViewImpl
        XCTAssertNotNil(serialsViewController)
        
        // Проверяем, что представление сериалов не равно nil
        XCTAssertNotNil(serialsViewController)
    }
}
